import java.util.List;

public interface StudentDAO {
    void createTable();
    void addStudent(Student student);
    List<Student> getAllStudents();
    void updateStudent(int id, String newRoomNo, String newContact);
    void deleteStudent(int id);
}
