import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnection {
    private static Connection con;

    public static Connection getConnection() {
        if (con == null) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hostel_db", "root", "123456789");
            } catch (Exception e) {
                System.out.println("Connection Error: " + e.getMessage());
            }
        }
        return con;
    }
}
