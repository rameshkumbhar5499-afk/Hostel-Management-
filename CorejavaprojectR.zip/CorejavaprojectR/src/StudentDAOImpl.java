import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDAOImpl implements StudentDAO {

    Connection con = MyConnection.getConnection();

    @Override
    public void createTable() {
        String query = "CREATE TABLE IF NOT EXISTS hostel_students (" +
                       "id INT PRIMARY KEY AUTO_INCREMENT," +
                       "name VARCHAR(100)," +
                       "roomNo VARCHAR(10)," +
                       "contact VARCHAR(15)," +
                       "admissionDate VARCHAR(20))";
        try (PreparedStatement ps = con.prepareStatement(query)) {
            ps.execute();
            System.out.println("✅ Table created successfully (if not existed).");
        } catch (SQLException e) {
            System.out.println("Error creating table: " + e.getMessage());
        }
    }

    @Override
    public void addStudent(Student student) {
        String query = "INSERT INTO hostel_students(name, roomNo, contact, admissionDate) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, student.getName());
            ps.setString(2, student.getRoomNo());
            ps.setString(3, student.getContact());
            ps.setString(4, student.getAdmissionDate());
            ps.executeUpdate();
            System.out.println("✅ Student added successfully!");
        } catch (SQLException e) {
            System.out.println("Error adding student: " + e.getMessage());
        }
    }

    @Override
    public List<Student> getAllStudents() {
        List<Student> list = new ArrayList<>();
        String query = "SELECT * FROM hostel_students";
        try (PreparedStatement ps = con.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new Student(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("roomNo"),
                        rs.getString("contact"),
                        rs.getString("admissionDate")
                ));
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving students: " + e.getMessage());
        }
        return list;
    }

    @Override
    public void updateStudent(int id, String newRoomNo, String newContact) {
        String query = "UPDATE hostel_students SET roomNo = ?, contact = ? WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, newRoomNo);
            ps.setString(2, newContact);
            ps.setInt(3, id);
            int rows = ps.executeUpdate();
            if (rows > 0)
                System.out.println("✅ Student updated successfully!");
            else
                System.out.println("⚠️ Student not found.");
        } catch (SQLException e) {
            System.out.println("Error updating student: " + e.getMessage());
        }
    }

    @Override
    public void deleteStudent(int id) {
        String query = "DELETE FROM hostel_students WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(query)) {
            ps.setInt(1, id);
            int rows = ps.executeUpdate();
            if (rows > 0)
                System.out.println("✅ Student deleted successfully!");
            else
                System.out.println("⚠️ Student not found.");
        } catch (SQLException e) {
            System.out.println("Error deleting student: " + e.getMessage());
        }
    }
}
