import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StudentDAO dao = new StudentDAOImpl();
        int choice;

        System.out.println("====== HOSTEL MANAGEMENT SYSTEM ======");

        do {
            System.out.println("\n========== MENU ==========");
            System.out.println("1. Create Table");
            System.out.println("2. Add Student");
            System.out.println("3. View All Students");
            System.out.println("4. Update Student");
            System.out.println("5. Delete Student");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    dao.createTable();
                    break;

                case 2:
                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Room No: ");
                    String roomNo = sc.nextLine();
                    System.out.print("Enter Contact: ");
                    String contact = sc.nextLine();
                    System.out.print("Enter Admission Date (YYYY-MM-DD): ");
                    String date = sc.nextLine();

                    Student student = new Student(name, roomNo, contact, date);
                    dao.addStudent(student);
                    break;

                case 3:
                    List<Student> list = dao.getAllStudents();
                    System.out.println("\n===== STUDENT LIST =====");
                    for (Student s : list) {
                        System.out.println(s.getId() + " | " + s.getName() + " | " +
                                           s.getRoomNo() + " | " + s.getContact() + " | " + s.getAdmissionDate());
                    }
                    break;

                case 4:
                    System.out.print("Enter Student ID to Update: ");
                    int uid = sc.nextInt(); sc.nextLine();
                    System.out.print("Enter New Room No: ");
                    String newRoom = sc.nextLine();
                    System.out.print("Enter New Contact: ");
                    String newContact = sc.nextLine();
                    dao.updateStudent(uid, newRoom, newContact);
                    break;

                case 5:
                    System.out.print("Enter Student ID to Delete: ");
                    int did = sc.nextInt();
                    dao.deleteStudent(did);
                    break;

                case 6:
                    System.out.println("🚪 Exiting... Goodbye!");
                    break;

                default:
                    System.out.println("⚠️ Invalid choice. Try again.");
            }

        } while (choice != 6);

        sc.close();
    }
}
