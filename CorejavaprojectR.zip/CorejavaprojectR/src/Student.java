public class Student {
    private int id;
    private String name;
    private String roomNo;
    private String contact;
    private String admissionDate;

    public Student(int id, String name, String roomNo, String contact, String admissionDate) {
        this.id = id;
        this.name = name;
        this.roomNo = roomNo;
        this.contact = contact;
        this.admissionDate = admissionDate;
    }

    public Student(String name, String roomNo, String contact, String admissionDate) {
        this.name = name;
        this.roomNo = roomNo;
        this.contact = contact;
        this.admissionDate = admissionDate;
    }

    // Getters
    public int getId() { return id; }
    public String getName() { return name; }
    public String getRoomNo() { return roomNo; }
    public String getContact() { return contact; }
    public String getAdmissionDate() { return admissionDate; }
}
